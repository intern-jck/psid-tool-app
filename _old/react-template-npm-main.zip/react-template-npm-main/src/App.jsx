import React from 'react';
import './App.css';

const App = () =>{
    return (
      <div className='App'>
        <h1>
          React App with NPM
        </h1>
      </div>
    )
}

export default App;
